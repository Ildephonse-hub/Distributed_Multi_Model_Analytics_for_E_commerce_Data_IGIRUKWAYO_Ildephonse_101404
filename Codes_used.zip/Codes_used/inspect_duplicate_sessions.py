
import glob
import json
from collections import defaultdict

duplicate_ids = {
    "sess_626a12177b",
    "sess_cfbf8c0a02",
    "sess_3fa7cf1e0b",
    "sess_c1890dece9",
}

matches = defaultdict(list)

# Scan the original files but retain only the four target IDs.
for filename in sorted(glob.glob("sessions_*.json")):
    with open(filename, "r", encoding="utf-8") as file:
        sessions = json.load(file)

    for session in sessions:
        if session.get("session_id") in duplicate_ids:
            matches[session["session_id"]].append({
                "source_file": filename,
                "record": session,
            })

    del sessions

print("DUPLICATE RECORD COMPARISON")

for session_id in sorted(duplicate_ids):
    records = matches[session_id]

    print("\n" + "=" * 70)
    print("SESSION ID:", session_id)
    print("NUMBER OF MATCHING RECORDS:", len(records))

    for index, entry in enumerate(records, start=1):
        print(f"\nRECORD {index} — FILE: {entry['source_file']}")
        print(json.dumps(
            entry["record"],
            indent=2,
            ensure_ascii=False
        ))

    if len(records) == 2:
        identical = records[0]["record"] == records[1]["record"]
        print("\nRECORDS IDENTICAL:", identical)

print("\nOriginal session files were not modified.")
