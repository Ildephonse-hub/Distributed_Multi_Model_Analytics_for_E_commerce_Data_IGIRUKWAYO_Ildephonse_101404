
import os
import glob
import functools

from pyspark.sql import SparkSession, functions as F, types as T

# Start Spark using two local CPU threads
spark = (
    SparkSession.builder
    .appName("Phase7_Sequential_Funnel")
    .master("local[2]")
    .config("spark.hadoop.fs.defaultFS", "file:///")
    .getOrCreate()
)

# Define only the fields needed
page_schema = T.ArrayType(
    T.StructType([
        T.StructField("page_type", T.StringType()),
        T.StructField("timestamp", T.StringType())
    ])
)

session_schema = T.StructType([
    T.StructField("session_id", T.StringType()),
    T.StructField("page_views", page_schema)
])

stages = ["home", "product_detail", "cart", "checkout", "confirmation"]

files = sorted(glob.glob(os.path.abspath("generated_data/sessions_*.json")))
results = []

print("SESSION FILES:", len(files))

for i, file in enumerate(files, 1):

    data = (
        spark.read
        .schema(session_schema)
        .option("multiLine", True)
        .json(file)
    )

    events = data.select(
        "session_id",
        F.explode("page_views").alias("p")
    )

    # Find the first timestamp for each stage in each session
    session_stages = events.groupBy("session_id").agg(
        *[
            F.min(
                F.when(
                    F.col("p.page_type") == stage,
                    F.col("p.timestamp")
                )
            ).alias(stage)
            for stage in stages
        ]
    )

    home = F.col("home").isNotNull()

    product = (
        home
        & F.col("product_detail").isNotNull()
        & (F.col("product_detail") > F.col("home"))
    )

    cart = (
        product
        & F.col("cart").isNotNull()
        & (F.col("cart") > F.col("product_detail"))
    )

    checkout = (
        cart
        & F.col("checkout").isNotNull()
        & (F.col("checkout") > F.col("cart"))
    )

    confirmation = (
        checkout
        & F.col("confirmation").isNotNull()
        & (F.col("confirmation") > F.col("checkout"))
    )

    conditions = [home, product, cart, checkout, confirmation]

    summary = session_stages.agg(
        *[
            F.sum(F.when(condition, 1).otherwise(0)).alias(stages[j])
            for j, condition in enumerate(conditions)
        ]
    )

    results.append(summary)

    print("PROCESSED:", i, "OF", len(files))

# Combine the results from all 20 files
combined = functools.reduce(
    lambda x, y: x.unionByName(y),
    results
)

final = combined.agg(
    *[F.sum(stage).alias(stage) for stage in stages]
)

row = final.first().asDict()

print("\nSEQUENTIAL FUNNEL - UNIQUE SESSIONS")

for stage in stages:
    print(stage + ":", int(row[stage] or 0))

# Save results using ordinary Python (no Spark worker required)
import csv

os.makedirs("visualization_data", exist_ok=True)

output_file = os.path.join(
    "visualization_data",
    "sequential_conversion_funnel.csv"
)

with open(output_file, "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)

    writer.writerow(["stage", "sessions", "stage_order"])

    for index, stage in enumerate(stages):
        writer.writerow([
            stage,
            int(row[stage] or 0),
            index + 1
        ])

print("\nRESULTS SAVED SUCCESSFULLY:", output_file)

spark.stop()