import csv
import glob
import matplotlib.pyplot as plt

input_file = glob.glob(
    "visualization_data/customer_segments/part-*.csv"
)[0]

segments = []
revenues = []

with open(input_file, "r", encoding="utf-8") as file:
    reader = csv.DictReader(file)

    for row in reader:
        segments.append(row["customer_segment"])
        revenues.append(float(row["revenue"]))

plt.figure(figsize=(9, 5))
plt.bar(segments, revenues)

plt.title("Revenue by Customer Segment")
plt.xlabel("Customer Segment")
plt.ylabel("Total Revenue")
plt.xticks(rotation=20)
plt.grid(axis="y")
plt.tight_layout()

output_file = "visualization_graphs/customer_segments.png"
plt.savefig(output_file, dpi=300)
plt.close()

print("GRAPH SAVED:", output_file)
print("SEGMENTS ANALYZED:", len(segments))