import csv
import glob
import matplotlib.pyplot as plt

# Read most-viewed products
view_file = glob.glob(
    "visualization_data/top_viewed_products/part-*.csv"
)[0]

view_names = []
view_counts = []

with open(view_file, encoding="utf-8") as file:
    for row in csv.DictReader(file):
        view_names.append(row["product_id"])
        view_counts.append(int(row["views"]))

# Read most-purchased products
purchase_file = glob.glob(
    "visualization_data/top_purchased_products/part-*.csv"
)[0]

purchase_names = []
purchase_counts = []

with open(purchase_file, encoding="utf-8") as file:
    for row in csv.DictReader(file):
        purchase_names.append(row["product_id"])
        purchase_counts.append(int(row["units_sold"]))

# Graph 1: Most-viewed products
plt.figure(figsize=(10, 6))
plt.barh(view_names[::-1], view_counts[::-1])
plt.title("Top 10 Most-Viewed Products")
plt.xlabel("Number of Views")
plt.ylabel("Product ID")
plt.tight_layout()
plt.savefig("visualization_graphs/top_viewed_products.png", dpi=300)
plt.close()

# Graph 2: Most-purchased products
plt.figure(figsize=(10, 6))
plt.barh(purchase_names[::-1], purchase_counts[::-1])
plt.title("Top 10 Most-Purchased Products")
plt.xlabel("Units Sold")
plt.ylabel("Product ID")
plt.tight_layout()
plt.savefig("visualization_graphs/top_purchased_products.png", dpi=300)
plt.close()

print("GRAPH SAVED: visualization_graphs/top_viewed_products.png")
print("GRAPH SAVED: visualization_graphs/top_purchased_products.png")
print("VIEWED PRODUCTS ANALYZED:", len(view_names))
print("PURCHASED PRODUCTS ANALYZED:", len(purchase_names))