import csv
import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime

input_file = "visualization_data/daily_sales_trends.csv"
output_file = "visualization_graphs/sales_trends.png"

dates = []
revenues = []

with open(input_file, "r", encoding="utf-8") as file:
    reader = csv.DictReader(file)

    for row in reader:
        dates.append(datetime.strptime(row["sales_date"], "%Y-%m-%d"))
        revenues.append(float(row["daily_revenue"]))

plt.figure(figsize=(12, 6))

plt.plot(dates, revenues, marker="o", markersize=3)

plt.title("Daily Sales Revenue Trends")
plt.xlabel("Sales Date")
plt.ylabel("Daily Revenue")

plt.gca().xaxis.set_major_formatter(
    mdates.DateFormatter("%d %b")
)

plt.xticks(rotation=45)
plt.grid(True)
plt.tight_layout()

plt.savefig(output_file, dpi=300)
plt.close()

print("GRAPH SAVED:", output_file)
print("DAYS ANALYZED:", len(dates))