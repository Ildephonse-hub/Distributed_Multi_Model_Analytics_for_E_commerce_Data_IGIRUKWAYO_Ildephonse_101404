
import glob
import json
from collections import Counter

session_id_counts = Counter()
total_records = 0
null_id_records = 0

# Read each session file individually.
for filename in sorted(glob.glob("sessions_*.json")):
    with open(filename, "r", encoding="utf-8") as file:
        sessions = json.load(file)

    for session in sessions:
        total_records += 1
        session_id = session.get("session_id")

        if session_id is None:
            null_id_records += 1
        else:
            session_id_counts[session_id] += 1

    del sessions
    print("Checked:", filename)

duplicates = {
    session_id: count
    for session_id, count in session_id_counts.items()
    if count > 1
}

print("\nSESSION ID UNIQUENESS REPORT")
print("Total session records:", total_records)
print("Records with null session IDs:", null_id_records)
print("Distinct non-null session IDs:", len(session_id_counts))
print("Number of duplicated IDs:", len(duplicates))
print("Extra occurrences caused by duplicates:",
      sum(count - 1 for count in duplicates.values()))

print("\nDUPLICATED SESSION IDS")
if duplicates:
    for session_id, count in duplicates.items():
        print(session_id, "appears", count, "times")
else:
    print("No duplicate session IDs found.")

print("\nEXPECTED RECORD COUNT MATCH:",
      total_records == 2_000_000)
