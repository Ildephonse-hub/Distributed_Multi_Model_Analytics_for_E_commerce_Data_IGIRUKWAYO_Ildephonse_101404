
import json
import glob
import os
from collections import Counter

# This script reads the original generated files.
# It does not modify or delete any dataset.

def load_json(filename):
    with open(filename, "r", encoding="utf-8") as file:
        return json.load(file)


print("STEP 1: Loading reference identifiers...")

users = load_json("users.json")
user_ids = {row["user_id"] for row in users}
del users

products = load_json("products.json")
product_ids = {row["product_id"] for row in products}
product_category_ids = {
    row.get("category_id") for row in products
}
del products

categories = load_json("categories.json")
category_ids = {row["category_id"] for row in categories}
del categories

print("Users:", len(user_ids))
print("Products:", len(product_ids))
print("Categories:", len(category_ids))

print("\nSTEP 2: Checking products' category references...")

missing_product_categories = len(
    product_category_ids - category_ids
)
print("Distinct category IDs referenced by products:",
      len(product_category_ids))
print("Unknown product category IDs:",
      missing_product_categories)

print("\nSTEP 3: Scanning sessions...")

session_ids = set()
session_user_missing = 0
session_viewed_product_missing = 0
session_page_product_missing = 0
session_page_category_missing = 0
conversion_counts = Counter()
session_files = sorted(glob.glob("sessions_*.json"))

for filename in session_files:
    rows = load_json(filename)

    for session in rows:
        session_ids.add(session.get("session_id"))
        conversion_counts.update(
            [session.get("conversion_status")]
        )

        if session.get("user_id") not in user_ids:
            session_user_missing += 1

        for product_id in session.get("viewed_products", []):
            if product_id not in product_ids:
                session_viewed_product_missing += 1

        for page in session.get("page_views", []):
            product_id = page.get("product_id")
            category_id = page.get("category_id")

            if (product_id is not None
                    and product_id not in product_ids):
                session_page_product_missing += 1

            if (category_id is not None
                    and category_id not in category_ids):
                session_page_category_missing += 1

    del rows
    print("Scanned:", filename)

session_ids.discard(None)

print("\nSESSION VALIDATION")
print("Session files:", len(session_files))
print("Distinct non-null session IDs:", len(session_ids))
print("Sessions with unknown users:", session_user_missing)
print("Unknown viewed product references:",
      session_viewed_product_missing)
print("Unknown page-view product references:",
      session_page_product_missing)
print("Unknown page-view category references:",
      session_page_category_missing)

print("\nSTEP 4: Checking transactions...")

transactions = load_json("transactions.json")

missing_transaction_users = 0
missing_transaction_sessions = 0
missing_transaction_products = 0
null_transaction_sessions = 0

for transaction in transactions:
    user_id = transaction.get("user_id")
    session_id = transaction.get("session_id")

    if user_id not in user_ids:
        missing_transaction_users += 1

    if not session_id:
        null_transaction_sessions += 1
    elif session_id not in session_ids:
        missing_transaction_sessions += 1

    for item in transaction.get("items", []):
        if item.get("product_id") not in product_ids:
            missing_transaction_products += 1

print("Transactions:", len(transactions))
print("Transactions with unknown users:",
      missing_transaction_users)
print("Transactions with null session IDs:",
      null_transaction_sessions)
print("Transactions with non-null but unknown session IDs:",
      missing_transaction_sessions)
print("Unknown transaction item product references:",
      missing_transaction_products)

print("\nVALIDATION COMPLETE")
print("Original JSON files were not modified.")
