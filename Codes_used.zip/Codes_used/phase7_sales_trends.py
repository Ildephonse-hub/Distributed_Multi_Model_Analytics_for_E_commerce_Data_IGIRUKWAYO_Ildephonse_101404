
import os
import csv

from pyspark.sql import SparkSession, functions as F

# Start Spark
spark = (
    SparkSession.builder
    .appName("Phase7_Sales_Trends")
    .master("local[2]")
    .config("spark.hadoop.fs.defaultFS", "file:///")
    .getOrCreate()
)

# Read all 500,000 transactions
transactions = (
    spark.read
    .option("multiLine", True)
    .json(os.path.abspath("generated_data/transactions.json"))
)

# Calculate daily revenue and transaction count
daily_sales = (
    transactions
    .withColumn("sales_date", F.to_date("timestamp"))
    .groupBy("sales_date")
    .agg(
        F.count("*").alias("transactions"),
        F.round(F.sum("total"), 2).alias("daily_revenue")
    )
    .orderBy("sales_date")
)

# Display results
print("\nDAILY SALES TRENDS")
daily_sales.show(100, False)

# Calculate overall summary
daily_sales.agg(
    F.round(F.sum("daily_revenue"), 2).alias("total_revenue"),
    F.round(F.avg("daily_revenue"), 2).alias("average_daily_revenue"),
    F.max("daily_revenue").alias("highest_daily_revenue"),
    F.min("daily_revenue").alias("lowest_daily_revenue"),
    F.count("*").alias("number_of_days")
).show(truncate=False)

# Save results using Python CSV
os.makedirs("visualization_data", exist_ok=True)

output_file = os.path.join(
    "visualization_data",
    "daily_sales_trends.csv"
)

rows = daily_sales.collect()

with open(output_file, "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["sales_date", "transactions", "daily_revenue"])

    for row in rows:
        writer.writerow([
            str(row["sales_date"]),
            row["transactions"],
            row["daily_revenue"]
        ])

print("\nRESULTS SAVED:", output_file)

spark.stop()
