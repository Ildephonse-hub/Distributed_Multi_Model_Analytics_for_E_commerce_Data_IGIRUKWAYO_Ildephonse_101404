import csv
import matplotlib.pyplot as plt

input_file = "visualization_data/sequential_conversion_funnel.csv"

stages = []
sessions = []

with open(input_file, encoding="utf-8") as file:
    reader = csv.DictReader(file)

    for row in reader:
        stages.append(row["stage"])
        sessions.append(int(row["sessions"]))

plt.figure(figsize=(10, 6))

plt.bar(stages, sessions)

plt.title("Sequential E-commerce Conversion Funnel")
plt.xlabel("Conversion Stage")
plt.ylabel("Number of Sessions")
plt.xticks(rotation=20)
plt.grid(axis="y")
plt.tight_layout()

output_file = "visualization_graphs/conversion_funnel.png"

plt.savefig(output_file, dpi=300)
plt.close()

print("GRAPH SAVED:", output_file)
print("FUNNEL STAGES:", len(stages))